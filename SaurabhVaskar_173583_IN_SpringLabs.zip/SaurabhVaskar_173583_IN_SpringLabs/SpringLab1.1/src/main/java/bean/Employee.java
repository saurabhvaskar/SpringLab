package bean;

public class Employee {
	int employee_id;
	String employee_name;
	int employee_salary;
	String employee_bu;
	int employee_age;
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public int getEmployee_salary() {
		return employee_salary;
	}
	public void setEmployee_salary(int employee_salary) {
		this.employee_salary = employee_salary;
	}
	public String getEmployee_bu() {
		return employee_bu;
	}
	public void setEmployee_bu(String employee_bu) {
		this.employee_bu = employee_bu;
	}
	public int getEmployee_age() {
		return employee_age;
	}
	public void setEmployee_age(int emplyee_age) {
		this.employee_age = emplyee_age;
	}
	
	
}
