package Executor;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Employee;

public class ExecutorMain {

	public static void main(String[] args) { 
	ConfigurableApplicationContext ctx=new ClassPathXmlApplicationContext("employee.xml");
	Employee emplo=(Employee)ctx.getBean("emp");
	
	System.out.println("===============================");
	System.out.println("Employee Details");
	System.out.println("-------------------------------");
	System.out.println(   "Employee Id     : "+emplo.getEmployee_id()
						+"\nEmployee Name   : "+emplo.getEmployee_name()
						+"\nEmployee Salary : "+emplo.getEmployee_salary()
						+"\nEmployee BU     : "+emplo.getEmployee_bu()
						+"\nEmployee Age    : "+emplo.getEmployee_age());
	System.out.println("===============================");
	
	ctx.close();
	}

}
