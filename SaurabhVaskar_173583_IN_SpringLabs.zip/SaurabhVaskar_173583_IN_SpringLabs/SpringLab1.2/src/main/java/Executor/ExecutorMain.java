package Executor;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import Bean.Employee;

public class ExecutorMain {

	public static void main(String[] args) {
	
	ConfigurableApplicationContext ctx=new ClassPathXmlApplicationContext("employeelab1.1.xml");
	Employee emp=(Employee)ctx.getBean("employee");
	
	System.out.println("=========================");
	System.out.println("   Employee details");
	System.out.println("-------------------------");
	System.out.println(emp);
	System.out.println("=========closing=========");
	
	ctx.close();
	}

}
