package com.cg.restController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@Controller
public class ProductController {

	@Autowired
	private ProductRepo repo;

	@GetMapping("/")
	public ModelAndView product(Model model) {
		return new ModelAndView("AddProduct", "productdetails", new Product());
	}

	@ExceptionHandler({ java.sql.SQLIntegrityConstraintViolationException.class,
			org.springframework.web.util.NestedServletException.class,
			org.springframework.orm.jpa.JpaSystemException.class, javax.persistence.PersistenceException.class,
			org.hibernate.exception.ConstraintViolationException.class })

	@PostMapping("newproduct")
	public ModelAndView addProduct(@ModelAttribute("productdetails") Product prod, Model model) {
		repo.saveProduct(prod);
		return new ModelAndView("success", "productdetails", new Product());
	}

	@GetMapping("/displayproducts")
	public ModelAndView findAllProducts(Model model) {

		Iterable<Product> productList = repo.getAllProduct();

		return new ModelAndView("displayproducts", "productList", productList);
	}

	@GetMapping("newproduct")
	public ModelAndView searchAllproduct(Model model) {

		return new ModelAndView("addproduct", "productdetails", new Product());
	}

	public ModelAndView showErrors() {
		return new ModelAndView("error");
	}

}
