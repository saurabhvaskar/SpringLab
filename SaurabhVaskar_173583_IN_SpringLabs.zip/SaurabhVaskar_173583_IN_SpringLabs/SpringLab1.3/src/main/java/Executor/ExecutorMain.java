package Executor;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import Bean.SBU;

public class ExecutorMain {

	public static void main(String[] args) {
	
	ConfigurableApplicationContext ctx=new ClassPathXmlApplicationContext("employeelab1.3.xml");
	SBU sbu=(SBU)ctx.getBean("sbu1");
	
	System.out.println("=========================");
	System.out.println("   Employee details");
	System.out.println("-------------------------");
	System.out.println(sbu);
	System.out.println("=========closing=========");
	
	ctx.close();
	}

}
