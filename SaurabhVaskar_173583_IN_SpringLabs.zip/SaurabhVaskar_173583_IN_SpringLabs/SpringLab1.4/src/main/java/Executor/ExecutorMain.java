package Executor;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import Entity.Employee;

public class ExecutorMain {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("employeLab14.xml");
		Employee emp=(Employee)ctx.getBean("employee1.4");
		
		Scanner scan=new Scanner(System.in);
		
		System.out.print("Employee ID     : ");
		int empId=scan.nextInt();//100
		
		if (emp.getEmployeeId()==empId) {
			
			System.out.println("\nEmployee info:");
			System.out.println("Employee Id     : "+emp.getEmployeeId());
			System.out.println("Employee Name   : "+emp.getEmployeeName());
			System.out.println("Employee Salary : "+emp.getEmployeeSalary());
			
		} else {
			System.out.println("\nWrong EmployeId Program terminated!");

		}
	}

}
