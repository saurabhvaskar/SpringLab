package com.cg.service;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Trainee;
import com.cg.repo.TraineeRepo;

@Service
@Transactional
public class TraineeServiceImpl implements ITraineeService {
	
	@Autowired
	TraineeRepo repo;

	@Override
	public void addTrainee(@Valid Trainee trainee) {
		repo.save(trainee);
		
	}
	
	@Override
	public Trainee getById(int id) {
		return repo.findById(id).get();
	}

	@Override
	public void deleteEmployee(Trainee emp)  {
			// if record found in database then employee will be deleted
			repo.delete(emp);

	}

	@Override
	public Iterable<Trainee> findAll() {
		// return all employees from database
		return repo.findAll();
	}

	
}
