package com.cg.service;

import javax.validation.Valid;

import com.cg.entity.Trainee;

public interface ITraineeService {

	void addTrainee(@Valid Trainee trainee);

	Trainee getById(int id);

	void deleteEmployee(Trainee emp);

	Iterable<Trainee> findAll();

}
