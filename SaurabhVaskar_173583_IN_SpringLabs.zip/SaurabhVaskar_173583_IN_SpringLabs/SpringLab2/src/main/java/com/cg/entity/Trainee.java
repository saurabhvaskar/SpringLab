package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
@Table(name="trainee_master2")
public class Trainee {
	@Id
	//@NotEmpty(message="Trainee ID is mandatory")
	//@Size(min=4,max=5,message="Must be of 4 digits")
	private int traineeId;
	
	@NotEmpty(message="Trainee Name is mandatory")
	@Size(min=4,max=14,message="Minimum 4 and Maximum 14 characters required")
	private String traineeName;
	
	@NotEmpty(message="trainee Domain is mandatory")
	private String traineeDomain;
	
	@NotEmpty(message="Location is mandatory")
	private String traineeLocation;

	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	
	
}
