package com.cg.ctrl;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.ITraineeService;

@Controller
public class TraineeController {

	@Autowired
	ITraineeService service;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		return "index";
	}

	ArrayList<String> cityList;
	ArrayList<String> skillList;

	@RequestMapping(value = "index")
	public String index(Model model) {
		return "index";
	}

	@RequestMapping(value = "showLogin")
	public String prepareLogin(Model model) {
		System.out.println("In prepareLogin() method");
		model.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping(value = "checkLogin")
	public String checkLogin(@ModelAttribute("login") @Valid Login login, BindingResult results, Model m) {
		// Logic to validate userName and password against database
		// m.addAttribute("login",login);
		if (results.hasErrors()) {
			System.out.println("Error");

			return "login";
		} else {
			m.addAttribute("login", login);
			System.out.println("Valid  dd");

			if (login.getUserName().equals("root") && login.getPassword().equals("root123")) {
				m.addAttribute("login", login);
				return "loginSuccess";
			} else {
				m.addAttribute("invalid", "invalid credentials \n please enter right credentials");
				return "login";
			}
		}
	}

	@RequestMapping(value = "showRegister")
	public String prepareRegister(Model model) {

		cityList = new ArrayList<String>();

		cityList.add("Chennaii");
		cityList.add("Bangalore");
		cityList.add("Pune");
		cityList.add("Mumbai");

		skillList = new ArrayList<String>();

		skillList.add("Java");
		skillList.add("Struts");
		skillList.add("Spring");
		skillList.add("Hibernate");

		model.addAttribute("cityList", cityList);
		model.addAttribute("skillList", skillList);

		model.addAttribute("trainee", new Trainee());
		return "register";
	}

	@RequestMapping(value = "checkRegister")
	public String checkRegister(@ModelAttribute("trainee") @Valid Trainee trainee, BindingResult result, Model model) {
		if (result.hasErrors()) {
			System.out.println("Error");
			model.addAttribute("cityList", cityList);
			model.addAttribute("skillList", skillList);

			return "register";
		} else {
			model.addAttribute("trainee", trainee);

			// method.invoke(obj);
			service.addTrainee(trainee);
			System.out.println("Valid  dd");
			return "loginSuccess";
		}
	}

	@RequestMapping(value = "deleteTrainee")
	public String deleteTrainee(Model model) {
		System.out.println("In prepareLogin() method");
		// model.addAttribute("login",new Login());
		return "delete";
	}
	
	@RequestMapping("/delete")
	public String delete(Model model) {
		model.addAttribute("trainee", null);
		return "delete";
	}

	@RequestMapping("getempfordelete")
	public String getEmpForDel(int id, Model model) {
		Trainee trainee = service.getById(id);
		System.out.println(trainee);
		model.addAttribute("trainee", trainee);
		return "delete";

	}

	@RequestMapping("deleteemployee")
	public String deleteEmp(Model model,Trainee trainee) {
		System.out.println( trainee);
		if ( trainee != null) {
			service.deleteEmployee(trainee);
			trainee = null;
			model.addAttribute("operation", "Trainee deleted");
			return "home";
		} else {
			model.addAttribute("error", "Provide valid Trainee Id");
			return "delete";
		}
	}
	
	@RequestMapping("/all")
	public String retrieveAll(Model model) {
		Iterable<Trainee> iterable = service.findAll();
		List<Trainee> list = new ArrayList<>();
		iterable.forEach(list::add);
		for (Trainee trainee : list) {
			System.out.println(trainee);
		}
		model.addAttribute("list", list);
		return "retrieveall";
	}

	@RequestMapping("/get")
	public String rtPage(Model model) {
		model.addAttribute("trainee", null);
		return "retrieve";
	}

	@RequestMapping("getemp")
	public String getEmp(int id, Model model) {
		Trainee trainee = service.getById(id);
		System.out.println(trainee);
		model.addAttribute("trainee", trainee);
		return "retrieve";

	}
	
	@RequestMapping("/modify")
	public String modify(Model model) {
		cityList = new ArrayList<String>();

		cityList.add("Mumbai");
		cityList.add("Bangalore");
		cityList.add("Chennai");
		cityList.add("Delhi");

		skillList = new ArrayList<String>();

		skillList.add("Java");
		skillList.add("Struts");
		skillList.add("Spring");
		skillList.add("Hibernate");
		skillList.add("Python");
		model.addAttribute("trainee", new Trainee());
		model.addAttribute("cityList", cityList);
		model.addAttribute("domain", skillList);
		return "modify";

	}

	@RequestMapping("getempformodify")
	public String getEmpForMod(int id, Model model,Trainee trainee) {
		trainee = service.getById(id);
		System.out.println(trainee);
		model.addAttribute("trainee", trainee);
		model.addAttribute("cityList", cityList);
		model.addAttribute("domain", skillList);
		return "modify";
	}

	@RequestMapping("modifyemployee")
	public String modifyEmp(@ModelAttribute("trainee") Trainee trainee, BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("error", "Plese provide Valid trainee data");
			model.addAttribute("cityList", cityList);
			model.addAttribute("domain", skillList);
			return "modify";
		} else {
			service.addTrainee(trainee);;
			model.addAttribute("operation", "Trainee modified");
			return "home";
		}
	}

}
